-- MultiPress Telemetry widget for FrSky ETHOS 1.6.8+
-- v1.2.7 — Clock is handled only by one dedicated HH:MM speech path.

local DOUBLE_SECONDS, LONG_SECONDS = 0.40, 0.50

local function isClock(s)
  return s ~= nil and string.find(string.lower(s:name() or ""), "clock", 1, true) ~= nil
end
local function nameOf(s) return s and s:name() or "Not assigned" end
local function valueOf(s)
  if not s then return "--" end
  if isClock(s) then return os.date("%H:%M") end
  local v = s:stringValue()
  return (v and v ~= "") and v or "--"
end

-- This is the ONLY Clock playback path. It never passes the Clock Source's
-- internal value to system.playNumber(), preventing a duplicate HH:MM:SS/raw
-- timer announcement. ETHOS units identify the two components explicitly.
local function playClockOnce()
  local t = os.date("*t")
  system.playNumber(t.hour, UNIT_HOUR, 0)
  system.playNumber(t.min, UNIT_MINUTE, 0)
end
local function playSource(s)
  if not s then return end
  if isClock(s) then
    playClockOnce()
    return
  end
  local v = s:value()
  if v ~= nil then system.playNumber(v, s:unit(), s:decimals()) end
end

local function create()
  return { switchSource=nil, shortSource=nil, doubleSource=nil, longSource=nil,
    down=false, downAt=0, longDone=false, pending=false, releasedAt=0,
    switchOn=false, switchValue="--", shortValue="--", doubleValue="--", longValue="--" }
end

-- Settings are only available from ETHOS Configure widget.
local function configure(w)
  local l = form.addLine("Momentary switch")
  form.addSourceField(l,nil,function() return w.switchSource end,function(v) w.switchSource=v end)
  l=form.addLine("Short press")
  form.addSourceField(l,nil,function() return w.shortSource end,function(v) w.shortSource=v end)
  l=form.addLine("Double press")
  form.addSourceField(l,nil,function() return w.doubleSource end,function(v) w.doubleSource=v end)
  l=form.addLine("Long press")
  form.addSourceField(l,nil,function() return w.longSource end,function(v) w.longSource=v end)
end
local function read(w)
  w.switchSource=storage.read("switchSource"); w.shortSource=storage.read("shortSource")
  w.doubleSource=storage.read("doubleSource"); w.longSource=storage.read("longSource")
end
local function write(w)
  storage.write("switchSource",w.switchSource); storage.write("shortSource",w.shortSource)
  storage.write("doubleSource",w.doubleSource); storage.write("longSource",w.longSource)
end
local function refresh(w,on)
  local a,b,c,d=valueOf(w.switchSource),valueOf(w.shortSource),valueOf(w.doubleSource),valueOf(w.longSource)
  if a~=w.switchValue or b~=w.shortValue or c~=w.doubleValue or d~=w.longValue or on~=w.switchOn then
    w.switchValue,w.shortValue,w.doubleValue,w.longValue,w.switchOn=a,b,c,d,on; lcd.invalidate()
  end
end
local function wakeup(w)
  local now=os.clock()
  local raw=w.switchSource and w.switchSource:value() or nil
  local on=raw~=nil and raw>0
  refresh(w,on)
  if w.pending and now-w.releasedAt>=DOUBLE_SECONDS then w.pending=false; playSource(w.shortSource) end
  if not w.switchSource then return end
  if on and not w.down then
    w.down,w.downAt,w.longDone=true,now,false
  elseif on and w.down and not w.longDone and now-w.downAt>=LONG_SECONDS then
    w.longDone,w.pending=true,false; playSource(w.longSource)
  elseif not on and w.down then
    w.down=false
    if not w.longDone then
      if w.pending and now-w.releasedAt<=DOUBLE_SECONDS then w.pending=false; playSource(w.doubleSource)
      else w.pending,w.releasedAt=true,now end
    end
  end
end
local function row(y,label,value,w) lcd.drawText(4,y,label); lcd.drawText(w-4,y,value,RIGHT) end
local function paint(w)
  local width,height=lcd.getWindowSize(); local copy="MultiPress V1 Christian Salcedo copyright"
  lcd.font(FONT_XL); local _,th=lcd.getTextSize("MultiPress"); lcd.drawText(width/2,2,"MultiPress",CENTERED)
  local _,lh=lcd.getTextSize("Switch: Not assigned"); lcd.font(FONT_XS); local _,ch=lcd.getTextSize(copy)
  local y,bottom=th+8,height-ch-4
  lcd.font(FONT_XL)
  if y+lh<=bottom then local txt="Switch: "..nameOf(w.switchSource); if w.switchOn then txt=txt.." ON" end; lcd.drawText(width/2,y,txt,CENTERED); y=y+lh+4 end
  if y+lh<=bottom then row(y,"Short",w.shortValue,width); y=y+lh+4 end
  if y+lh<=bottom then row(y,"Double",w.doubleValue,width); y=y+lh+4 end
  if y+lh<=bottom then row(y,"Long",w.longValue,width) end
  lcd.font(FONT_XS); if height>=th+ch+6 then lcd.drawText(width-2,height-ch-2,copy,RIGHT) end
end
local function init()
  -- No event callback: ETHOS retains scrolling-wheel navigation.
  system.registerWidget({key="mprsbtn",name="MultiPress",create=create,configure=configure,
    read=read,write=write,wakeup=wakeup,paint=paint,title=false})
end
return {init=init}
