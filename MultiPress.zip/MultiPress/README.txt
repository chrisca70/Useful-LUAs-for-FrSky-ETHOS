MultiPress Widget — ETHOS 1.6.8+

Christian Salcedo copyright 
MADE IN THE USA by a Colombian (Boyacá) brain

2026 Version 1.2.7

DISCLAIMER
I am not liable for any damages caused by this widget

DESCRIPTION
This widget enables a momentary button or toggle switch to announce system or telemetry values via 3 different press actuations. If telemetry is not being transmitted, the value will not be announced.
(1) Short press (example: Radio CLOCK)
(2) Two short presses in quick succession (example: RX Battery)
(3) Long press (example: Altitude)

INSTALLATION
(1) Unzip the file 
(2) Copy the MultiPress folder to your scripts folder. The MultiPress folder contains the file main.lua
(3) Restart your radio

SET UP
(1) Create a new whole screen, any other type of screen layout will not display the widget correctly
(2) Configure the widget: select your momentary button or toggle switch, then select your values **use only Telemetry or System values.**


*****ENJOY! Widget has been tested with the FrSky Suite simulator, if you find bugs, good luck, this is for my personal use and works fine in my X18R****
